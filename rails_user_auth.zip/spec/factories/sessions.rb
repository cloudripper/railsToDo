FactoryBot.define do
  factory :session do
    user {"MyString"}
  end
end
