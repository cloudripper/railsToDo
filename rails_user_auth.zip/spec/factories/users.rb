FactoryBot.define do
  factory :user do
    username {'testtest'}
    password {'testtest'}
  end
end
